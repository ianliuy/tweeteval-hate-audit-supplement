"""Retrieve immutable official files and verify their exact bytes. Does not upload."""
from pathlib import Path
import argparse, json, hashlib, urllib.request

def main():
    p=argparse.ArgumentParser();p.add_argument('--destination',required=True);args=p.parse_args()
    root=Path(__file__).resolve().parent
    manifest=json.loads((root/'provenance/pinned-release-manifest.json').read_text(encoding='utf-8'))
    out=Path(args.destination);out.mkdir(parents=True,exist_ok=True)
    for f in manifest['official_files']:
        rel=f['path'].replace('\\','/').removeprefix('data/official/')
        target=out/rel
        assert target.resolve().is_relative_to(out.resolve())
        if target.exists():data=target.read_bytes()
        else:
            url=f"https://raw.githubusercontent.com/cardiffnlp/tweeteval/{manifest['commit']}/datasets/{rel}"
            with urllib.request.urlopen(url,timeout=60) as response:data=response.read()
        assert len(data)==f['bytes'] and hashlib.sha256(data).hexdigest()==f['sha256'],rel
        target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    print('Verified',len(manifest['official_files']),'immutable release files.')

if __name__=='__main__':main()
