"""Standalone checks from preserved predictions and text-key hashes; no training.
Requires NumPy. Default checks 8 bootstrap draws per group and all stored quantiles.
Use --bootstrap-draws 5000 to regenerate every published draw (more CPU time).
"""
from pathlib import Path
from collections import defaultdict
import argparse,csv,json,hashlib,os
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[key]='2'
import numpy as np
ROOT=Path(__file__).resolve().parent

def rows(name):
    with (ROOT/name).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def close(a,b,label):assert np.allclose(a,b,rtol=1e-10,atol=1e-11),label
def div(a,b):return np.divide(a,b,out=np.zeros_like(np.asarray(a),dtype=float),where=np.asarray(b)!=0)
def f1(cm):
    tn,fp,fn,tp=np.moveaxis(cm,-1,0)
    return .5*(div(2*tn,2*tn+fp+fn)+div(2*tp,2*tp+fp+fn))
def metrics(y,p,o):
    tn=((y==0)&(p==0)).sum(axis=1);fp=((y==0)&(p==1)).sum(axis=1)
    fn=((y==1)&(p==0)).sum(axis=1);tp=((y==1)&(p==1)).sum(axis=1)
    correct=p==y; old=o==y
    return dict(n=np.full(len(p),len(y)),true_hate=np.full(len(p),int(y.sum())),true_nonhate=np.full(len(p),len(y)-int(y.sum())),
        tn=tn,fp=fp,fn=fn,tp=tp,macro_f1=f1(np.stack([tn,fp,fn,tp],axis=-1)),accuracy=correct.mean(axis=1),
        predicted_hate_rate=p.mean(axis=1),persistence=(p==o).mean(axis=1),flip_rate=(p!=o).mean(axis=1),
        flips=(p!=o).sum(axis=1),wrong_to_right=(correct&~old).sum(axis=1),right_to_wrong=(~correct&old).sum(axis=1),
        precision_nonhate=div(tn,tn+fn),recall_nonhate=div(tn,tn+fp),f1_nonhate=div(2*tn,2*tn+fp+fn),
        precision_hate=div(tp,tp+fp),recall_hate=div(tp,tp+fn),f1_hate=div(2*tp,2*tp+fp+fn))

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--bootstrap-draws',type=int,default=8);args=parser.parse_args()
    assert 1<=args.bootstrap_draws<=5000
    manifest=json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
    for name,h in manifest['sha256'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h,name
    audit={p.stem:dict(np.load(p,allow_pickle=False)) for p in (ROOT/'audit-inputs').glob('*.npz')}
    for row in rows('tables/all-split-overlap-audit.csv'):
        z=audit[row['config']];rule=row['rule'];source=row['source'];target=row['target']
        x=z[f'{rule}_{source}_keys'];y=z[f'{rule}_{source}_labels']
        a=z[f'{rule}_{target}_keys'];b=z[f'{rule}_{target}_labels']
        sets=defaultdict(set)
        for k,v in zip(x,y):sets[str(k)].add(int(v))
        groups=np.array(['nonoverlap' if k not in sets else 'agreeing' if sets[k]=={int(v)} else
                         'conflicting' if int(v) not in sets[k] else 'ambiguous' for k,v in zip(a,b)])
        shared=groups!='nonoverlap';targetkeys=set(a)
        actual=dict(shared_target_rows=int(shared.sum()),shared_unique_keys=len(set(a[shared])),
                    matching_source_rows=sum(k in targetkeys for k in x),
                    **{g:int(np.sum(groups==g)) for g in ['agreeing','conflicting','ambiguous','nonoverlap']})
        for k,v in actual.items():assert v==int(row[k]),(row,k,v)
    removal=rows('tables/control-overlap-removals.csv')
    for rule in ['raw','trimmed']:
        z=audit['hate'];x=z[f'{rule}_train_keys'];y=z[f'{rule}_train_labels'];test=set(z[f'{rule}_test_keys'])
        matching=np.array([k in test for k in x]);d=json.loads((ROOT/f'methods/deletions_{rule}.json').read_text())
        purge=np.flatnonzero(matching);assert np.array_equal(purge,d['removed']['purge'])
        target=np.bincount(y[purge],minlength=2)
        for row in [r for r in removal if r['rule']==rule]:
            ix=np.array(d['removed'][row['condition']],dtype=int)
            assert len(ix)==len(set(ix)) and np.array_equal(np.bincount(y[ix],minlength=2),target)
            assert int(matching[ix].sum())==int(row['matching_train_rows_removed'])
            assert len(set(x[ix[matching[ix]]]))==int(row['matching_unique_keys_removed'])
    for row in rows('tables/control-overlap-summary.csv'):
        selected=[r for r in removal if r['rule']==row['rule']][:int(row['n_controls'])]
        a=np.array([int(r['matching_train_rows_removed']) for r in selected])
        for key,value in [('sum',a.sum()),('mean',a.mean()),('min',a.min()),('max',a.max())]:close(value,float(row[f'{key}_matching_rows_removed']),row)

    point={};predictions={};masks_by_model={}
    for p in sorted((ROOT/'predictions').glob('*.npz')):
        z=dict(np.load(p,allow_pickle=False));predictions[p.stem]=z
        y=z['y'];g=z['group'];pred=z['predictions']
        rule='trimmed' if p.stem.startswith('trimmed') else 'raw'
        assert np.array_equal(y,audit['hate'][f'{rule}_test_labels'])
        assert np.array_equal(z['key_sha256'],audit['hate'][f'{rule}_test_keys'])
        masks={'all':np.arange(len(y)),'overlap':np.flatnonzero(g!='nonoverlap')}
        masks.update({k:np.flatnonzero(g==k) for k in ['agreeing','conflicting','nonoverlap']})
        if p.stem.startswith('raw_'):
            for f in (ROOT/'subsets').glob('indices_*.txt'):
                key=f.stem.removeprefix('indices_');ix=np.loadtxt(f,dtype=int,ndmin=1)
                if key in masks:assert np.array_equal(ix,masks[key])
                masks[key]=ix
        masks_by_model[p.stem]=masks
        for group,ix in masks.items():
            metric=metrics(y[ix],pred[:,ix],pred[0,ix])
            for i,name in enumerate(z['names']):point[(p.stem,group,str(name))]={k:float(v[i]) for k,v in metric.items()}
    checked=0
    for file,kind in [('sparse-per-condition-metrics.csv','sparse'),('encoder-per-condition-metrics.csv','encoder'),('common-subset-per-condition-metrics.csv','subset')]:
        for row in rows('tables/'+file):
            model=(row['rule']+'_'+row['model']) if kind=='sparse' else ('encoder_'+row['encoder']) if kind=='encoder' else 'raw_'+row['model']
            group=row['subset'] if kind=='subset' else row['group']
            values=point[(model,group,row['condition'])]
            for k,v in values.items():
                if k in row:close(v,float(row[k]),(file,model,group,row['condition'],k))
            checked+=1
    for file,neural in [('control_summary.csv',False),('neural_summary.csv',True)]:
        for row in rows('tables/'+file):
            model='encoder_'+row['encoder'] if neural else row['rule']+'_'+row['model']
            names=predictions[model]['names'];group=row['group'];metric=row['metric']
            v=np.array([point[(model,group,str(n))][metric] for n in names])
            actual={'original':v[0],'purge':v[1],'control_mean':v[2:].mean(),'control_sd':v[2:].std(ddof=1),
                    'control_mcse':v[2:].std(ddof=1)/np.sqrt(len(v)-2),'control_min':v[2:].min(),'control_max':v[2:].max()}
            for k,value in actual.items():close(value,float(row[k]),(file,model,group,metric,k))
            assert len(v)-2==int(row['n_controls'])
    for row in rows('tables/evaluation_subsets.csv'):
        ix=masks_by_model['raw_word_lr'][row['subset']];z=predictions['raw_word_lr']
        for k,v in [('rows',len(ix)),('hate',z['y'][ix].sum()),('nonhate',len(ix)-z['y'][ix].sum()),('raw_text_keys',len(set(z['key_sha256'][ix])))]:assert v==int(row[k]),row

    intervals=0;resampled_groups=0
    for model,z in predictions.items():
        neural=model.startswith('encoder');rule='trimmed' if model.startswith('trimmed') else 'raw'
        stored=dict(np.load(ROOT/'bootstrap'/('encoders.npz' if neural else model+'.npz'),allow_pickle=False))
        data=[r for r in rows('tables/'+('neural_uncertainty.csv' if neural else 'uncertainty.csv'))
              if ('encoder_'+r['encoder'] if neural else r['rule']+'_'+r['model'])==model]
        for row in data:
            key=(row['encoder']+'_' if neural else '')+row['group']+'_'+row['metric']+('' if neural else '_'+row['contrast'])
            lo,hi=np.quantile(stored[key],[.025,.975]);close([lo,hi],[float(row['lower']),float(row['upper'])],key)
            names=z['names'];v=np.array([point[(model,row['group'],str(n))][row['metric']] for n in names])
            estimate=v[1]-(v[0] if row['contrast']=='purge_minus_original' else v[2:].mean())
            close(estimate,float(row['estimate']),(model,key,'estimate'));intervals+=1
        # A deterministic prefix (or all 5,000 requested draws) is regenerated from predictions.
        for group in ['all','overlap','agreeing','conflicting','nonoverlap']:
            ix=masks_by_model[model][group];pred=z['predictions'][:,ix];y=z['y'][ix]
            _,cluster=np.unique(audit['hate'][f'{rule}_test_cluster'][ix],return_inverse=True)
            nc=int(cluster.max())+1;denom=np.bincount(cluster,minlength=nc);names=z['names']
            cm=np.stack([np.bincount(cluster*4+y*2+p,minlength=nc*4).reshape(nc,4) for p in pred],axis=1).astype(float)
            rng=np.random.default_rng(71001 if neural else 61001)
            for start in range(0,args.bootstrap_draws,64):
                size=min(64,args.bootstrap_draws-start);draw=rng.integers(0,nc,(size,nc))
                w=np.bincount((draw+np.arange(size)[:,None]*nc).ravel(),minlength=size*nc).reshape(size,nc).astype(float)
                total=w@denom;sampled=f1((w@cm.reshape(nc,-1)).reshape(size,len(names),4)) if neural or group=='all' else None
                for row in [r for r in data if r['group']==group]:
                    metric=row['metric'];contrast=row['contrast'];isorig=contrast=='purge_minus_original'
                    if metric=='macro_f1':v=sampled[:,1]-(sampled[:,0] if isorig else sampled[:,2:].mean(axis=1))
                    else:
                        a=(pred==y) if metric=='accuracy' else (pred!=pred[0])
                        delta=a[1].astype(float)-(a[0] if isorig else a[2:].mean(axis=0))
                        v=(w@np.bincount(cluster,weights=delta,minlength=nc))/total
                    key=(row['encoder']+'_' if neural else '')+group+'_'+metric+('' if neural else '_'+contrast)
                    close(v,stored[key][start:start+size],(model,key,'draws'))
            resampled_groups+=1
    report={'verified_files':len(manifest['sha256']),'audit_comparisons':66,'random_deletion_lists':2000,
            'point_metric_records_checked':checked,'unique_metric_records':len(point),'paired_intervals_checked':intervals,
            'bootstrap_groups_recomputed':resampled_groups,'draws_per_group_recomputed':args.bootstrap_draws,
            'training_runs':0,'all_checks_passed':True}
    (ROOT/'verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
