"""Recalculate all revision metrics and paired cluster intervals from predictions."""
import bootstrap_env
from bootstrap_env import ROOT
from collections import defaultdict, Counter
import json
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from audit import read_split, groups, digest, json_write
from experiments import confusion_by_cluster, f1_cm

RP = json.loads((ROOT / "revision-protocol.json").read_text())
OUT = ROOT / RP["output_directory"]
GROUPS = RP["reporting_groups"]


def mask_for(group, labels):
    if group == "all":
        return np.ones(len(labels), dtype=bool)
    if group == "overlap":
        return labels != "nonoverlap"
    return labels == group


def divide(a, b):
    return np.divide(a, b, out=np.zeros_like(np.asarray(a), dtype=float), where=np.asarray(b) != 0)


def metric_rows(rule, model, names, predictions, y, group):
    output = []
    for g in GROUPS:
        mask = mask_for(g, group)
        truth = y[mask]
        old = predictions[0, mask]
        for name, pred in zip(names, predictions):
            p = pred[mask]
            cm = np.bincount(truth * 2 + p, minlength=4)
            tn, fp, fn, tp = map(int, cm)
            correct0, correct = old == truth, p == truth
            wtr = int(np.sum(~correct0 & correct))
            rtw = int(np.sum(correct0 & ~correct))
            assert wtr - rtw == int(correct.sum() - correct0.sum())
            assert wtr + rtw == int(np.sum(p != old)), "Binary-class flips must change correctness"
            output.append({"rule": rule, "model": model, "group": g, "condition": name, "n": len(truth),
                "true_nonhate": int(np.sum(truth == 0)), "true_hate": int(np.sum(truth == 1)),
                "tn": tn, "fp": fp, "fn": fn, "tp": tp, "accuracy": float(correct.mean()),
                "macro_f1": float(f1_cm(cm)), "predicted_hate_rate": float(p.mean()),
                "precision_nonhate": float(divide(tn, tn + fn)), "recall_nonhate": float(divide(tn, tn + fp)),
                "f1_nonhate": float(divide(2 * tn, 2 * tn + fp + fn)),
                "precision_hate": float(divide(tp, tp + fp)), "recall_hate": float(divide(tp, tp + fn)),
                "f1_hate": float(divide(2 * tp, 2 * tp + fp + fn)),
                "flips": wtr + rtw, "flip_rate": float(np.mean(p != old)), "wrong_to_right": wtr, "right_to_wrong": rtw})
    return output


def cluster_weights(rng, n, size):
    # All rows of a key share its integer sampling multiplicity.
    draws = rng.integers(0, n, (size, n))
    return np.bincount((draws + np.arange(size)[:, None] * n).ravel(), minlength=size * n).reshape(size, n).astype(float)


def bootstrap(rule, model, names, predictions, x, y, groups_array):
    b = RP["bootstrap_repetitions"]
    records, saved = [], {}
    for g in GROUPS:
        mask = mask_for(g, groups_array)
        _, cluster = np.unique(x[mask], return_inverse=True)
        n_cluster = int(cluster.max()) + 1
        denominator = np.bincount(cluster, minlength=n_cluster)
        pred, truth = predictions[:, mask], y[mask]
        correct = (pred == truth).astype(float)
        flips = (pred != pred[0]).astype(float)
        # Per-row average is correct for accuracy/flip rates with a common denominator.
        # F1 is nonlinear and is recomputed per condition before averaging below.
        contrasts = {}
        for metric, values in [("accuracy", correct), ("flip_rate", flips)]:
            for label, reference in [("purge_minus_original", values[0]), ("purge_minus_random_mean", values[2:].mean(axis=0))]:
                delta = values[1] - reference
                contrasts[(metric, label)] = (np.bincount(cluster, weights=delta, minlength=n_cluster), float(delta.mean()))
        cm = None
        if g == "all":
            cm = np.stack([confusion_by_cluster(truth, p, cluster, n_cluster) for p in pred], axis=1).astype(float)
            point = f1_cm(cm.sum(axis=0))
        dist = {key: np.empty(b) for key in contrasts}
        if cm is not None:
            dist[("macro_f1", "purge_minus_original")] = np.empty(b)
            dist[("macro_f1", "purge_minus_random_mean")] = np.empty(b)
        rng = np.random.default_rng(RP["bootstrap_seed"])
        for start in range(0, b, 64):
            size = min(64, b - start)
            weights = cluster_weights(rng, n_cluster, size)
            denom = weights @ denominator
            for key, (numerator, _) in contrasts.items():
                dist[key][start:start + size] = (weights @ numerator) / denom
            if cm is not None:
                totals = (weights @ cm.reshape(n_cluster, -1)).reshape(size, len(names), 4)
                values = f1_cm(totals)
                dist[("macro_f1", "purge_minus_original")][start:start + size] = values[:, 1] - values[:, 0]
                dist[("macro_f1", "purge_minus_random_mean")][start:start + size] = values[:, 1] - values[:, 2:].mean(axis=1)
        for (metric, contrast), values in dist.items():
            if metric == "macro_f1":
                estimate = float(point[1] - (point[0] if contrast == "purge_minus_original" else point[2:].mean()))
            else:
                estimate = contrasts[(metric, contrast)][1]
            lo, hi = np.quantile(values, [.025, .975])
            records.append({"rule": rule, "model": model, "group": g, "metric": metric, "contrast": contrast,
                            "estimate": estimate, "lower": float(lo), "upper": float(hi), "rows": int(mask.sum()), "text_clusters": n_cluster,
                            "repetitions": b, "conditional_controls": RP["n_controls_per_configuration"]})
            saved[f"{g}_{metric}_{contrast}"] = values
        print(rule, model, g, "paired cluster intervals complete", flush=True)
    np.savez_compressed(OUT / f"{rule}_{model}_bootstrap.npz", **saved)
    return records


def main():
    metrics, intervals, baseline, directions = [], [], [], []
    configurations = RP["configurations"]
    expected_names = ["original", "purge"] + [f"random_{s}" for s in range(RP["control_seed_start"], RP["control_seed_end_inclusive"] + 1)]
    for rule in ["raw", "trimmed"]:
        tx, ty = read_split("hate", "train", rule)
        x, y = read_split("hate", "test", rule)
        g = groups(tx, ty, x, y)
        labels = defaultdict(set)
        for text, label in zip(tx, ty):
            labels[text].add(int(label))
        directional = defaultdict(list)
        for i, (text, label) in enumerate(zip(x, y)):
            if text in labels:
                directional[(tuple(sorted(labels[text])), int(label))].append(i)
        for (train_labels, test_label), ix in sorted(directional.items()):
            directions.append({"rule": rule, "train_label_set": ",".join(map(str, train_labels)), "test_label": test_label,
                               "test_rows": len(ix), "unique_text_keys": len(set(x[ix]))})
        majority = int(np.argmax(np.bincount(ty, minlength=2)))
        for group in GROUPS:
            m = mask_for(group, g)
            for label in [0, 1]:
                p = np.full(m.sum(), label)
                baseline.append({"rule": rule, "group": group, "constant_label": label, "is_training_majority": label == majority,
                    "rows": int(m.sum()), "keys": len(set(x[m])), "nonhate": int(np.sum(y[m] == 0)), "hate": int(np.sum(y[m] == 1)),
                    "accuracy": float(np.mean(p == y[m])), "macro_f1": float(f1_cm(np.bincount(y[m] * 2 + p, minlength=4)))})
    for rule, model in configurations:
        x, y = read_split("hate", "test", rule)
        tx, ty = read_split("hate", "train", rule)
        with np.load(OUT / f"{rule}_{model}_predictions.npz", allow_pickle=False) as z:
            names = [k for k in z.files if k in ["original", "purge"] or k.startswith("random_")]
            assert names == expected_names
            assert np.array_equal(y, z["y"])
            g = z["group"]
            assert np.array_equal(g, groups(tx, ty, x, y))
            pred = np.stack([z[n] for n in names])
        rows = metric_rows(rule, model, names, pred, y, g)
        metrics.extend(rows)
        intervals.extend(bootstrap(rule, model, names, pred, x, y, g))
    frame = pd.DataFrame(metrics)
    summary = []
    outcome_names = ["macro_f1", "accuracy", "flip_rate", "flips", "wrong_to_right", "right_to_wrong", "predicted_hate_rate"]
    for (rule, model, group), part in frame.groupby(["rule", "model", "group"], sort=False):
        part = part.set_index("condition")
        controls = part.loc[part.index.str.startswith("random_")]
        assert len(controls) == RP["n_controls_per_configuration"]
        for metric in outcome_names:
            values = controls[metric].to_numpy()
            target = float(part.loc["purge", metric])
            sd = float(np.std(values, ddof=1))
            summary.append({"rule": rule, "model": model, "group": group, "metric": metric,
                "original": float(part.loc["original", metric]), "purge": target, "control_mean": float(values.mean()),
                "control_sd": sd, "control_mcse": sd / np.sqrt(len(values)), "control_min": float(values.min()), "control_max": float(values.max()),
                **{f"q{q:g}": float(np.quantile(values, q / 100)) for q in [2.5, 25, 50, 75, 97.5]},
                "n_controls": len(values), "controls_lt_purge": int(np.sum(values < target)), "controls_eq_purge": int(np.sum(values == target)),
                "controls_gt_purge": int(np.sum(values > target)), "empirical_midrank": float((np.sum(values < target) + .5 * np.sum(values == target)) / len(values))})
    # Ensure error-count explanations are additive over the actual disjoint groups.
    for (rule, model, condition), part in frame.groupby(["rule", "model", "condition"]):
        p = part.set_index("group")
        columns = ["tn", "fp", "fn", "tp", "flips", "wrong_to_right", "right_to_wrong"]
        assert np.array_equal(p.loc["all", columns].to_numpy(), p.loc[["agreeing", "conflicting", "nonoverlap"], columns].sum().to_numpy())
    frame.to_csv(OUT / "metrics.csv", index=False)
    pd.DataFrame(intervals).to_csv(OUT / "uncertainty.csv", index=False)
    pd.DataFrame(baseline).to_csv(OUT / "baselines.csv", index=False)
    pd.DataFrame(directions).to_csv(OUT / "label_direction.csv", index=False)
    pd.DataFrame(summary).to_csv(OUT / "control_summary.csv", index=False)
    json_write(OUT / "analysis_verification.json", {"configurations": len(configurations), "conditions_each": len(expected_names),
        "metric_rows": len(frame), "paired_intervals": len(intervals), "additive_transition_checks": len(configurations) * len(expected_names),
        "protocol_sha256": digest(ROOT / "revision-protocol.json"), "script_sha256": digest(ROOT / "scripts/revision_analysis.py")})


if __name__ == "__main__":
    with threadpool_limits(limits=RP["threads"]):
        main()
