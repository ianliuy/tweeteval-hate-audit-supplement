"""Run every frozen model/condition; save predictions, deletion indices and uncertainty."""
import bootstrap_env
from bootstrap_env import ROOT
import json
import platform
import time
import warnings
import sys
from collections import Counter
import numpy as np
import pandas as pd
import scipy
import sklearn
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.metrics import f1_score, accuracy_score
from sklearn.exceptions import ConvergenceWarning
from threadpoolctl import threadpool_limits, threadpool_info
from audit import read_split, groups, digest, json_write

P = json.loads((ROOT / "protocol.json").read_text())
OUT = ROOT / "results"

def deletion_sets(x,y,t):
    test_keys=set(t)
    purge=np.flatnonzero([key in test_keys for key in x])
    counts=Counter(y[purge]); result={"original":np.array([],dtype=int),"purge":purge}
    for seed in P["random_deletion_seeds"]:
        rng=np.random.default_rng(seed)
        indices=np.sort(np.concatenate([rng.choice(np.flatnonzero(y==lab),size=n,replace=False)
                                      for lab,n in sorted(counts.items())]))
        assert Counter(y[indices])==counts and len(set(indices))==len(purge)
        result[f"random_{seed}"]=indices
    return result

def make_model(name):
    params=P["vectorizer_common"] | P["char_features" if name=="char_lr" else "word_features"]
    params["ngram_range"]=tuple(params["ngram_range"])
    vectorizer=TfidfVectorizer(**params)
    if name=="word_svm":
        estimator=LinearSVC(**P["linear_svm"],random_state=P["estimator_seed"])
    else:
        estimator=LogisticRegression(**P["logistic_regression"],random_state=P["estimator_seed"])
    return vectorizer,estimator

def confusion_by_cluster(y,p,cluster,n_clusters):
    return np.bincount(cluster*4+y*2+p,minlength=n_clusters*4).reshape(n_clusters,4)

def f1_cm(c):
    c=np.asarray(c); tn,fp,fn,tp=np.moveaxis(c,-1,0)
    d0=2*tn+fp+fn; d1=2*tp+fp+fn
    f0=np.divide(2*tn,d0,out=np.zeros_like(tn,dtype=float),where=d0!=0)
    f1=np.divide(2*tp,d1,out=np.zeros_like(tp,dtype=float),where=d1!=0)
    return (f0+f1)/2

def intervals(x,y,g,predictions,rule,model):
    # Same cluster draws for all conditions; no row-level independent resampling.
    names=list(predictions)
    keys,cluster=np.unique(x,return_inverse=True); k=len(keys)
    cms=np.stack([confusion_by_cluster(y,predictions[n],cluster,k) for n in names])
    rng=np.random.default_rng(P["bootstrap_seed"])
    b=P["bootstrap_repetitions"]
    draws=np.empty((b,len(names)))
    for i in range(b):
        weights=np.bincount(rng.integers(0,k,k),minlength=k)
        draws[i]=f1_cm(np.einsum("k,nkc->nc",weights,cms))
    point=np.array([f1_score(y,predictions[n],labels=[0,1],average="macro",zero_division=0) for n in names])
    contrasts=[]
    orig=names.index("original"); purge=names.index("purge"); random=[i for i,n in enumerate(names) if n.startswith("random_")]
    for label,delta,estimate in [
        ("purge_minus_original",draws[:,purge]-draws[:,orig],point[purge]-point[orig]),
        ("purge_minus_random_mean",draws[:,purge]-draws[:,random].mean(axis=1),point[purge]-point[random].mean())]:
        lo,hi=np.quantile(delta,[.025,.975])
        contrasts.append({"rule":rule,"model":model,"group":"all","metric":"macro_f1","contrast":label,
                          "estimate":estimate,"lower":lo,"upper":hi,"clusters":k})
    # Conditional subgroup intervals sample the subgroup's text clusters.
    for group in ["agreeing","conflicting","ambiguous","nonoverlap"]:
        mask=g==group
        if not mask.any(): continue
        key,ci=np.unique(x[mask],return_inverse=True); kg=len(key)
        delta=(predictions["purge"][mask]==y[mask]).astype(int)-(predictions["original"][mask]==y[mask]).astype(int)
        numerator=np.bincount(ci,weights=delta,minlength=kg); denominator=np.bincount(ci,minlength=kg)
        rng=np.random.default_rng(P["bootstrap_seed"])
        dist=[]
        for _ in range(b):
            sampled=rng.integers(0,kg,kg)
            dist.append(numerator[sampled].sum()/denominator[sampled].sum())
        lo,hi=np.quantile(dist,[.025,.975])
        contrasts.append({"rule":rule,"model":model,"group":group,"metric":"accuracy",
                          "contrast":"purge_minus_original","estimate":float(delta.mean()),"lower":lo,"upper":hi,"clusters":kg})
    np.savez_compressed(OUT/"predictions"/f"{rule}_{model}_bootstrap.npz",macro_f1=draws,conditions=np.array(names))
    return contrasts

def main():
    (OUT/"predictions").mkdir(parents=True,exist_ok=True)
    (OUT/"deletions").mkdir(exist_ok=True)
    rows,contrasts,runs=[],[],[]
    start=time.perf_counter()
    for rule in P["rules"]:
        train_x,train_y=read_split("hate","train",rule); test_x,y=read_split("hate","test",rule)
        group=groups(train_x,train_y,test_x,y); deletions=deletion_sets(train_x,train_y,test_x)
        import hashlib
        hashes=[hashlib.sha256(t.encode()).hexdigest() for t in test_x]
        pd.DataFrame({"row":np.arange(len(y)),"label":y,"key_sha256":hashes,"group":group}).to_csv(OUT/f"test_rows_{rule}.csv",index=False)
        for name,indices in deletions.items():
            json_write(OUT/"deletions"/f"{rule}_{name}.json",{"removed":indices.tolist(),
                "retained":np.setdiff1d(np.arange(len(train_y)),indices).tolist(),
                "removed_class_counts":{str(k):int(v) for k,v in Counter(train_y[indices]).items()},
                "matching_train_rows_removed":len(set(indices)&set(deletions["purge"]))})
        models=P["primary_models"] if rule=="raw" else P["sensitivity_models_trimmed"]
        for model_name in models:
            predictions={}
            for condition,removed in deletions.items():
                keep=np.ones(len(train_y),dtype=bool); keep[removed]=False
                if condition=="purge": assert not set(train_x[keep]) & set(test_x)
                vectorizer,estimator=make_model(model_name)
                t0=time.perf_counter()
                with warnings.catch_warnings(record=True) as caught:
                    warnings.simplefilter("always")
                    fitted=vectorizer.fit_transform(train_x[keep])
                    estimator.fit(fitted,train_y[keep])
                    predicted=estimator.predict(vectorizer.transform(test_x))
                assert not any(issubclass(w.category,ConvergenceWarning) for w in caught), "Nonconverged run"
                predictions[condition]=predicted
                runs.append({"rule":rule,"model":model_name,"condition":condition,"seconds":time.perf_counter()-t0,
                    "features":len(vectorizer.vocabulary_),"n_train":int(keep.sum()),
                    "estimator_params":estimator.get_params(),"vectorizer_params":{k:str(v) for k,v in vectorizer.get_params().items()},
                    "iterations":estimator.n_iter_.tolist() if hasattr(estimator.n_iter_,"tolist") else estimator.n_iter_,
                    "warnings":[str(w.message) for w in caught]})
                for group_name,mask in [("all",np.ones(len(y),dtype=bool))]+[(n,group==n) for n in ["agreeing","conflicting","ambiguous","nonoverlap"]]:
                    if not mask.any(): continue
                    rows.append({"rule":rule,"model":model_name,"condition":condition,"group":group_name,
                        "n_train":int(keep.sum()),"n_test":int(mask.sum()),"accuracy":accuracy_score(y[mask],predicted[mask]),
                        "macro_f1":f1_score(y[mask],predicted[mask],labels=[0,1],average="macro",zero_division=0),
                        "flips_from_original":int(np.sum(predicted[mask]!=predictions["original"][mask]))})
                print(rule,model_name,condition,f"{time.perf_counter()-t0:.1f}s",flush=True)
            np.savez_compressed(OUT/"predictions"/f"{rule}_{model_name}.npz",y=y,group=group,key_sha256=np.array(hashes),**predictions)
            contrasts.extend(intervals(test_x,y,group,predictions,rule,model_name))
    pd.DataFrame(rows).to_csv(OUT/"metrics.csv",index=False)
    pd.DataFrame(contrasts).to_csv(OUT/"uncertainty.csv",index=False)
    json_write(OUT/"runs.json",runs)
    json_write(OUT/"environment.json",{"python":sys.version,"platform":platform.platform(),"numpy":np.__version__,
        "pandas":pd.__version__,"scipy":scipy.__version__,"sklearn":sklearn.__version__,"threads":threadpool_info(),
        "seconds":time.perf_counter()-start,"protocol_sha256":digest(ROOT/"protocol.json")})
    print("Completed",len(runs),"runs",flush=True)

if __name__ == "__main__":
    with threadpool_limits(limits=P["threads"]):
        main()
