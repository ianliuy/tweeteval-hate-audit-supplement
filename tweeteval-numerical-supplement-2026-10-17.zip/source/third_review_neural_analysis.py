"""Analyze both predeclared probes on the same test keys, without model selection."""
import bootstrap_env
from bootstrap_env import ROOT
from pathlib import Path
import json
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from audit import read_split, groups, digest, json_write
from experiments import confusion_by_cluster, f1_cm
from third_review_analysis import summarize_predictions

OUT = ROOT / 'results/third-review-2026-10-01'
P = json.loads((ROOT/'third-review-protocol.json').read_text())
GROUPS = ['all', 'overlap', 'agreeing', 'conflicting', 'nonoverlap']


def predictions():
    names = ['original','purge']+[f'random_{s}' for s in range(41001,41021)]
    a = OUT/'encoder_predictions.npz'
    b = ROOT/'results/editorial-2026-10-01/neural/predictions.npz'
    with np.load(a,allow_pickle=False) as z:
        first = np.stack([z[k] for k in names]); truth=z['y']; group=z['group']
    with np.load(b,allow_pickle=False) as z:
        assert list(z['names']) == names
        assert np.array_equal(z['truth'],truth) and np.array_equal(z['groups'],group)
        second=z['predictions']
    return names, [('58M', first),('154M', second)], {str(p.relative_to(ROOT)):digest(p) for p in [a,b]}


def main():
    tx,ty=read_split('hate','train');x,y=read_split('hate','test');g=groups(tx,ty,x,y)
    names, models, inputs=predictions()
    records, summaries, intervals, saved=[],[],[],{}
    masks={'all':np.ones(len(y),bool),'overlap':g!='nonoverlap',**{k:g==k for k in GROUPS[2:]}}
    for model,pred in models:
        assert pred.shape==(22,2970) and np.isin(pred,[0,1]).all()
        for group,mask in masks.items():
            metrics=summarize_predictions(pred[:,mask],y[mask],pred[0,mask])
            metrics['flip_rate']=1-metrics['persistence']
            for i,name in enumerate(names):
                records.append({'encoder':model,'group':group,'condition':name,'n':int(mask.sum()),
                                **{k:float(v[i]) for k,v in metrics.items()}})
            for metric,v in metrics.items():
                summaries.append({'encoder':model,'group':group,'metric':metric,'original':float(v[0]),
                    'purge':float(v[1]),'control_mean':float(v[2:].mean()),'control_sd':float(v[2:].std(ddof=1)),
                    'control_mcse':float(v[2:].std(ddof=1)/np.sqrt(20)),
                    'control_min':float(v[2:].min()),'control_max':float(v[2:].max()),'n_controls':20})
            _,cluster=np.unique(x[mask],return_inverse=True)
            n=int(cluster.max())+1;denominator=np.bincount(cluster,minlength=n)
            cm=np.stack([confusion_by_cluster(y[mask],p[mask],cluster,n) for p in pred],axis=1).astype(float)
            correct=(pred[:,mask]==y[mask]);flips=(pred[:,mask]!=pred[0,mask])
            numerators={metric:np.bincount(cluster,weights=v[1].astype(float)-v[2:].mean(axis=0),minlength=n)
                        for metric,v in [('accuracy',correct),('flip_rate',flips)]}
            reps=P['supplementary_uncertainty']['bootstrap_repetitions']
            distributions={k:np.empty(reps) for k in ['macro_f1','accuracy','flip_rate']}
            rng=np.random.default_rng(P['supplementary_uncertainty']['seed'])
            for start in range(0,reps,64):
                size=min(64,reps-start);draw=rng.integers(0,n,(size,n))
                weight=np.bincount((draw+np.arange(size)[:,None]*n).ravel(),minlength=size*n).reshape(size,n).astype(float)
                total=weight@denominator
                sampled=f1_cm((weight@cm.reshape(n,-1)).reshape(size,len(names),4))
                distributions['macro_f1'][start:start+size]=sampled[:,1]-sampled[:,2:].mean(axis=1)
                for metric,num in numerators.items():
                    distributions[metric][start:start+size]=(weight@num)/total
            for metric,values in distributions.items():
                point=metrics[metric][1]-metrics[metric][2:].mean()
                lo,hi=np.quantile(values,[.025,.975])
                intervals.append({'encoder':model,'group':group,'metric':metric,'contrast':'purge_minus_control_mean',
                    'estimate':float(point),'lower':float(lo),'upper':float(hi),'rows':int(mask.sum()),
                    'clusters':n,'repetitions':reps,'conditional_controls':20})
                saved[f'{model}_{group}_{metric}']=values
            print(model,group,'paired text-key intervals calculated',flush=True)
    pd.DataFrame(records).to_csv(OUT/'neural_metrics.csv',index=False)
    pd.DataFrame(summaries).to_csv(OUT/'neural_summary.csv',index=False)
    pd.DataFrame(intervals).to_csv(OUT/'neural_uncertainty.csv',index=False)
    np.savez_compressed(OUT/'neural_bootstrap.npz',**saved)
    json_write(OUT/'neural-analysis-provenance.json',{'inputs':inputs,'script_sha256':digest(Path(__file__)),
        'protocol_sha256':digest(ROOT/'third-review-protocol.json'),'fits':44,'metrics':len(records),
        'intervals':len(intervals),'independent_datasets':1,'scope':'Two distinct frozen representations/pooling choices, not independent replication or a controlled comparison of pretraining corpus sizes'})


if __name__=='__main__':
    with threadpool_limits(2):main()
