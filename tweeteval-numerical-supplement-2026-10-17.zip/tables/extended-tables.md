# Extended numerical tables

These tables preserve the full existing summaries alongside the eight-page main paper. F1 is a proportion; accuracy, recall, predicted hate and persistence are percentages. Purge-minus-control differences and their 95% intervals are percentage points. Raw sparse controls number 1,000 per configuration; frozen probes use 20 each. Intervals are paired test-key bootstrap intervals conditional on fitted models and realized controls; they exclude training and annotation uncertainty. Deletion ranges are a different quantity. The 20-control encoder widths are not directly comparable estimates of general model stability. W to R and R to W mean wrong-to-right and right-to-wrong. N/H mean non-hate/hate; O/N in persistence columns mean overlap/non-overlap. Raw keys remove line endings only; trimmed keys additionally strip boundary whitespace. No new estimates are fitted here.

## A1 Official splits and train-test shared rows

| Configuration | Train | Valid. | Test | Raw overlap | Trimmed overlap |
| --- | --- | --- | --- | --- | --- |
| Emoji | 45,000 | 5,000 | 50,000 | 0 | 41 |
| Emotion | 3,257 | 374 | 1,421 | 0 | 0 |
| Hate | 9,000 | 1,000 | 2,970 | 231 | 233 |
| Irony | 2,862 | 955 | 784 | 0 | 0 |
| Offensive | 11,916 | 1,324 | 860 | 4 | 4 |
| Sentiment | 45,615 | 2,000 | 12,284 | 0 | 0 |
| Stance abortion | 587 | 66 | 280 | 0 | 0 |
| Stance atheism | 461 | 52 | 220 | 0 | 0 |
| Stance climate | 355 | 40 | 169 | 0 | 0 |
| Stance feminist | 597 | 67 | 285 | 0 | 0 |
| Stance hillary | 620 | 69 | 295 | 0 | 0 |

## A2 Other split pairs and within-split multi-label keys

| Configuration | Tr-Val raw | Tr-Val trim | Val-Test raw | Val-Test trim | ML train | ML val | ML test |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Emoji | 0 | 181 | 16 | 16 | 84 | 4 | 0 |
| Emotion | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Hate | 3 | 3 | 0 | 0 | 1 | 0 | 0 |
| Irony | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Offensive | 4 | 4 | 0 | 0 | 6 | 0 | 1 |
| Sentiment | 0 | 0 | 0 | 0 | 3 | 0 | 0 |
| Stance abortion | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| Stance atheism | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Stance climate | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Stance feminist | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Stance hillary | 1 | 1 | 0 | 0 | 0 | 0 | 0 |

## A3 Overlap label direction

| Training label set | Test label | Test rows | Distinct keys |
| --- | --- | --- | --- |
| {0} | 0 | 4 | 4 |
| {1} | 0 | 90 | 89 |
| {1} | 1 | 137 | 137 |

## A4 Baselines and sparse performance

| Predictor | Macro-F1 | Accuracy | Recall N | Recall H | Pred. H |
| --- | --- | --- | --- | --- | --- |
| Constant non-hate | 0.3665 | 57.85 | 100.00 | 0.00 | 0.00 |
| Constant hate | 0.2965 | 42.15 | 0.00 | 100.00 | 100.00 |
| Word LR original | 0.4558 | 49.76 | 19.03 | 91.93 | 85.59 |
| Word LR purge | 0.4674 | 50.30 | 21.13 | 90.34 | 83.70 |
| Character LR original | 0.4512 | 49.87 | 17.69 | 94.01 | 87.24 |
| Character LR purge | 0.4436 | 49.23 | 17.00 | 93.45 | 87.41 |
| Word SVM original | 0.4636 | 50.10 | 20.49 | 90.73 | 84.24 |
| Word SVM purge | 0.4740 | 50.67 | 22.24 | 89.70 | 82.79 |

## A5 Aggregate sparse comparisons

| Configuration | Original / purge | Control mean | Control range | Difference [95% CI] |
| --- | --- | --- | --- | --- |
| Word LR | 0.4558 / 0.4674 | 0.4646 | 0.4556-0.4762 | +0.28 [-0.30, +0.83] |
| Character LR | 0.4512 / 0.4436 | 0.4471 | 0.4372-0.4603 | -0.35 [-0.84, +0.14] |
| Word SVM | 0.4636 / 0.4740 | 0.4701 | 0.4602-0.4817 | +0.38 [-0.14, +0.93] |
| Word LR trim | 0.4558 / 0.4686 | 0.4649 | 0.4550-0.4786 | +0.37 [-0.20, +0.94] |

## A6 Complete sparse local comparisons

| Model | Group | Accuracy difference [95% CI] | Purge flips | Random mean [range] | Flip difference [95% CI] |
| --- | --- | --- | --- | --- | --- |
| Word LR | all | +0.07 [-0.41, +0.53] | 70 | 53.67 [33,77] | +0.55 [+0.09, +1.03] |
| Word LR | overlap | -4.14 [-7.52, -0.85] | 18 | 0.88 [0,5] | +7.41 [+4.45, +11.04] |
| Word LR | agreeing | -9.47 [-14.32, -4.79] | 14 | 0.65 [0,5] | +9.47 [+4.79, +14.32] |
| Word LR | conflicting | +4.19 [+1.01, +8.46] | 4 | 0.23 [0,2] | +4.19 [+1.01, +8.46] |
| Word LR | nonoverlap | +0.43 [+0.02, +0.84] | 52 | 52.79 [33,76] | -0.03 [-0.44, +0.41] |
| Character LR | all | -0.25 [-0.66, +0.15] | 53 | 55.15 [34,80] | -0.07 [-0.47, +0.33] |
| Character LR | overlap | -2.22 [-4.44, -0.31] | 7 | 0.89 [0,4] | +2.64 [+0.70, +4.82] |
| Character LR | agreeing | -4.27 [-7.53, -1.41] | 6 | 0.77 [0,4] | +3.71 [+0.86, +6.99] |
| Character LR | conflicting | +0.98 [-0.01, +2.98] | 1 | 0.12 [0,1] | +0.98 [-0.01, +2.98] |
| Character LR | nonoverlap | -0.09 [-0.48, +0.32] | 46 | 54.26 [34,78] | -0.30 [-0.69, +0.11] |
| Word SVM | all | +0.14 [-0.31, +0.60] | 63 | 56.87 [32,78] | +0.21 [-0.25, +0.66] |
| Word SVM | overlap | -3.29 [-6.65, -0.36] | 16 | 0.81 [0,5] | +6.58 [+3.65, +9.92] |
| Word SVM | agreeing | -8.08 [-12.77, -4.00] | 12 | 0.60 [0,5] | +8.08 [+4.00, +12.77] |
| Word SVM | conflicting | +4.21 [+0.99, +8.53] | 4 | 0.21 [0,2] | +4.21 [+0.99, +8.53] |
| Word SVM | nonoverlap | +0.43 [+0.03, +0.85] | 47 | 56.06 [32,77] | -0.33 [-0.73, +0.09] |

## A7 Correctness transitions relative to original training

| Model | Group | W to R | R to W | Net correct |
| --- | --- | --- | --- | --- |
| Word LR | overlap | 4 | 14 | -10 |
| Word LR | nonoverlap | 39 | 13 | +26 |
| Word LR | all | 43 | 27 | +16 |
| Character LR | overlap | 1 | 6 | -5 |
| Character LR | nonoverlap | 16 | 30 | -14 |
| Character LR | all | 17 | 36 | -19 |
| Word SVM | overlap | 4 | 12 | -8 |
| Word SVM | nonoverlap | 36 | 11 | +25 |
| Word SVM | all | 40 | 23 | +17 |

## A8 Fixed subgroup comparisons

| Model | Non-overlap F1 | Overlap pred. H | Non-overlap pred. H | Persistence O / N |
| --- | --- | --- | --- | --- |
| Word LR | 0.4533 / 0.4677 / 0.4625 | 98.27 / 92.21 | 84.52 / 82.99 | 92.21 / 98.10 |
| Char LR | 0.4500 / 0.4431 / 0.4455 | 99.13 / 96.10 | 86.24 / 86.67 | 96.97 / 98.32 |
| Word SVM | 0.4614 / 0.4740 / 0.4682 | 98.27 / 93.07 | 83.06 / 81.93 | 93.07 / 98.28 |

## A9 Retained representation support

| Representation | Rows | Equivalent | Cosine median / max | At least .80 | At least .90 |
| --- | --- | --- | --- | --- | --- |
| Raw word | 231 | 0 | 0.248 / 0.883 | 2 | 0 |
| Raw character | 231 | 0 | 0.277 / 0.846 | 3 | 0 |
| Trimmed word | 233 | 0 | 0.247 / 0.883 | 2 | 0 |

## A10 Similarity subset sensitivity

| Retained subset | Rows | H (%) | Word LR | Char LR | Word SVM |
| --- | --- | --- | --- | --- | --- |
| No exact overlap | 2739 | 40.71 | +0.52 | -0.24 | +0.58 |
| No word equivalent | 2722 | 40.63 | +0.52 | -0.24 | +0.58 |
| Char cosine < 0.80 | 2656 | 40.89 | +0.54 | -0.25 | +0.60 |
| Char cosine < 0.90 | 2685 | 40.63 | +0.54 | -0.25 | +0.59 |
| Char cosine < 0.95 | 2705 | 40.70 | +0.53 | -0.25 | +0.58 |

## A11 Frozen encoder comparisons

| Encoder | Original / purge F1 | Control mean [range] | F1 difference [95% CI] | O flips purge / mean |
| --- | --- | --- | --- | --- |
| 58M | 0.5215 / 0.5370 | 0.5355 [0.5308, 0.5392] | +0.15 [-0.44, +0.74] | 6 / 2.75 |
| 154M | 0.5337 / 0.5534 | 0.5470 [0.5438, 0.5505] | +0.64 [-0.05, +1.36] | 7 / 2.80 |
