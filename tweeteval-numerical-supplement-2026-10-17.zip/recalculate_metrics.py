"""Standalone numerical recalculation. Requires only Python 3 and NumPy."""
from pathlib import Path
import csv,json,hashlib
import numpy as np

ROOT=Path(__file__).resolve().parent

def metrics(y,p,original):
    tn=int(((y==0)&(p==0)).sum());fp=int(((y==0)&(p==1)).sum())
    fn=int(((y==1)&(p==0)).sum());tp=int(((y==1)&(p==1)).sum())
    f0=2*tn/(2*tn+fp+fn) if 2*tn+fp+fn else 0.
    f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.
    return dict(macro_f1=(f0+f1)/2,accuracy=(tn+tp)/len(y),predicted_hate_rate=float(p.mean()),
                persistence=float(np.mean(p==original)),tn=tn,fp=fp,fn=fn,tp=tp)

def main():
    manifest=json.loads((ROOT/'manifest.json').read_text())
    for name,expected in manifest['sha256'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected,name
    rows=[]
    for path in sorted((ROOT/'predictions').glob('*.npz')):
        with np.load(path,allow_pickle=False) as z:
            y=z['y'];g=z['group'];pred=z['predictions'];names=z['names']
            masks={'all':np.arange(len(y)),'overlap':np.flatnonzero(g!='nonoverlap')}
            masks.update({k:np.flatnonzero(g==k) for k in ['agreeing','conflicting','nonoverlap']})
            if path.stem in ['raw_word_lr','raw_char_lr','raw_word_svm']:
                masks.update({p.stem.removeprefix('indices_'):np.loadtxt(p,dtype=int,ndmin=1)
                              for p in (ROOT/'subsets').glob('indices_*.txt')})
            for group,ix in masks.items():
                for name,p in zip(names,pred):
                    rows.append(dict(model=path.stem,group=group,condition=str(name),n=len(ix),
                                     **metrics(y[ix],p[ix],pred[0,ix])))
    target=ROOT/'recalculated-metrics.csv'
    with target.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print(json.dumps({'verified_input_files':len(manifest['sha256']),'metric_rows':len(rows),'output':target.name}))

if __name__=='__main__':main()
